package jdbcdemo;
import java.sql.*;
public class JDBCDemo {
//jdbc:oracle:thin:@localhost:1521:XE [system on Default schema]
    

 public static void main(String[] args)
 {
  try
  {
   Class.forName("oracle.jdbc.OracleDriver");
   Connection c=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","admin");
   Statement s=c.createStatement();
   ResultSet result1=s.executeQuery("select * from emp");
   while(result1.next())
   {
    System.out.println(result1.getString(1));
    System.out.println(result1.getString(2));
   }
  }catch(SQLException e)
     {
      System.out.println(e);
     }
   catch(Exception i)
   {
    System.out.println(i);
   }
  
 }
}
